import { initTRPC } from "@trpc/server";
import superjson from "superjson";
import type { createContext } from "./context";

const t = initTRPC.context<typeof createContext>().create({
  transformer: superjson,
});

export const router = t.router;
export const publicQuery = t.procedure;
